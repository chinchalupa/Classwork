package problem;

public class FormatException extends Exception {

	public FormatException(String string) {
		super(string);
	}

	private static final long serialVersionUID = 1L;
	
}
