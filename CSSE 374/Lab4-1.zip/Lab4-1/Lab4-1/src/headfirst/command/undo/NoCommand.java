package headfirst.command.undo;

public class NoCommand implements Command {
	public void execute() { }
	public void undo() { }
}
