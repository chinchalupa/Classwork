package problem.blueberrymuffin;

import static org.junit.Assert.*;

/**
 * Created by Jeremy on 1/10/2016.
 */
public class VirtualThreadTest {

}