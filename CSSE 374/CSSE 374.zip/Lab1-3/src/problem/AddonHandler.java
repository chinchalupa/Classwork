package problem;

/**
 * Created by wrightjt on 12/6/2015.
 */
public interface AddonHandler {
    public void runHandler();
}
