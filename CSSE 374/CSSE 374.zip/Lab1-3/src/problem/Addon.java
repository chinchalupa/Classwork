package problem;

/**
 * Created by wrightjt on 12/6/2015.
 */
public abstract class Addon implements AddonHandler {

    public abstract void runHandler();
}
