package temp;

/**
 * Created by wrightjt on 12/3/2015.
 */
public interface IWeatherData {
    public double getTemperature();
    public double getHumidity();
    public double getPressure();
}
