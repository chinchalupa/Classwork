package temp;

/**
 * Created by wrightjt on 12/3/2015.
 */
public interface IDisplay {
    public void dataChanged(IWeatherData data);
}
