package problem;

/**
 * Created by wrightjt on 12/6/2015.
 */
public interface Parser {
    public void parse();
    public String getCompany();
    public String getData();
}
