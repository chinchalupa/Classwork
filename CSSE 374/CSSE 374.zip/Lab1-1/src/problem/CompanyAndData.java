package problem;

/**
 * Created by wrightjt on 12/6/2015.
 */
public abstract class CompanyAndData implements Parser {

    public abstract void parse();

    public abstract String getCompany();

    public abstract String getData();

}
