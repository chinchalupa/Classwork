package problem.question1;

import java.util.Collection;

public interface ISchool {
	public String getName();
	public Collection<IDepartment> getDepartments();
}
