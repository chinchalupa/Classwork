package problem.question1;

public interface IStaff extends IEmployee {
	public String getJobDescription();
}
