package problem.question1;

public interface IEmployee extends IPersonnel {
	public IEmployee getSupervisor();
}
