package problem.question1;

public interface ICourse {
	public String getName();
	public String getDescription();
}
