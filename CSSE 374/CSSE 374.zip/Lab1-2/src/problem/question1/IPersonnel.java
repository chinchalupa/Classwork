package problem.question1;

public interface IPersonnel {
	public int getId();
	public String getName();
}
