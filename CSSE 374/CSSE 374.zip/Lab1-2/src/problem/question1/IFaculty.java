package problem.question1;

public interface IFaculty extends IEmployee {
	public String getExpertise();
}
