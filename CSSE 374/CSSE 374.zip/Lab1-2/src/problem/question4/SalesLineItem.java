package problem.question4;

/**
 * Created by wrightjt on 12/1/2015.
 */
public class SalesLineItem {

    private int subtotal;

    public SalesLineItem(int subtotal) {
        this.subtotal = subtotal;
    }

    public int getSubtotal() {
        return subtotal;
    }
}
