package problem.question6;

/**
 * Created by wrightjt on 12/6/2015.
 */
public class C {

    public C() {
    }

    public void doB() {
        System.out.println("Did B");
    }

    public void doM1() {
        System.out.println("Did M1");
    }

    public void doM2() {
        System.out.println("Did M2");
    }

    public void doX() {
        System.out.println("Did X");
    }

    public void doY() {
        System.out.println("Did Y");
    }

    public void doZ() {
        System.out.println("Did Z");
    }
}
