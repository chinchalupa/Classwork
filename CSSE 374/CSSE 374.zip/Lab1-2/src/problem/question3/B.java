package problem.question3;

/**
 * Created by wrightjt on 12/1/2015.
 */
public class B {

    public B() {
    }

    public void calculate() {
        System.out.println("B calculated");
    }
}
