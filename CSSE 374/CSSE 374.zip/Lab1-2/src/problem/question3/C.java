package problem.question3;

/**
 * Created by wrightjt on 12/1/2015.
 */
public class C {

    public C() {
    }

    public void calculate() {
        System.out.println("C calculated");
    }
}
