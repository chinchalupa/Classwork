package problem.question7;

/**
 * Created by wrightjt on 12/1/2015.
 */
public class Clock extends Thread {

    public Clock() {
    }

    public void run() {
        System.out.println("I am inside a thread!");
    }
}
