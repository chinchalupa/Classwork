package problem.question7;

/**
 * Created by wrightjt on 12/1/2015.
 */
public class Game {

    public void beginPlay() {
        System.out.println("Begin Playing!");
    }

}
