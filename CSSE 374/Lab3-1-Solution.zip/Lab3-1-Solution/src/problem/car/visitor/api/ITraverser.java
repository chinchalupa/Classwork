package problem.car.visitor.api;

public interface ITraverser {
	public void accept(IVisitor v);
}
