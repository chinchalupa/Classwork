package problem.car.api;

public interface IEngine extends ICarPart {
	public int getCylinder();
	public float getCapacity();
}
