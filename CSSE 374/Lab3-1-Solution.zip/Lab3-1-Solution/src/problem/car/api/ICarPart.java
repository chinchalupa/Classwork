package problem.car.api;

public interface ICarPart {

}
