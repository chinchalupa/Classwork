package problem.car.api;

public interface IBody extends ICarPart {
	public String getType();
	public String getMaterial();
}
